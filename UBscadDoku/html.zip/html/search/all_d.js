var searchData=
[
  ['n_0',['n',['../db/dda/ub22_8212_doxy_8scad.html#a0e0ce22728faabe1c3d95817ca170247',1,'ub22.212Doxy.scad']]],
  ['naca_1',['naca',['../db/dda/ub22_8212_doxy_8scad.html#adfd6dda9c298a29e52f9273045700d47',1,'ub22.212Doxy.scad']]],
  ['naca_2',['NACA',['../db/dda/ub22_8212_doxy_8scad.html#a5ea498a0d404832c0c44bf16cea37494',1,'ub22.212Doxy.scad']]],
  ['name_3',['name',['../db/dda/ub22_8212_doxy_8scad.html#ab74e6bf80237ddc4109968cedc58c151',1,'ub22.212Doxy.scad']]],
  ['needs2d_4',['needs2D',['../db/dda/ub22_8212_doxy_8scad.html#a399b48652a15c1524d8bde0160f5b2ea',1,'ub22.212Doxy.scad']]],
  ['negred_5',['negRed',['../db/dda/ub22_8212_doxy_8scad.html#addda81985844a5f9378ed76bbb283d10',1,'ub22.212Doxy.scad']]],
  ['nozarea_6',['nozArea',['../db/dda/ub22_8212_doxy_8scad.html#a9c04bdfb9c76cd61e7305a8e0298f96c',1,'ub22.212Doxy.scad']]],
  ['nozzle_7',['nozzle',['../db/dda/ub22_8212_doxy_8scad.html#ad6d8226aee2fe24f56500b44c93eaf43',1,'ub22.212Doxy.scad']]],
  ['nut_8',['Nut',['../db/dda/ub22_8212_doxy_8scad.html#a5d9cc75e327185f132ba9cf371a74894',1,'ub22.212Doxy.scad']]],
  ['nut_9',['nut',['../db/dda/ub22_8212_doxy_8scad.html#a3c2b0f646bd363fe772c201a7d60138e',1,'ub22.212Doxy.scad']]]
];
