var searchData=
[
  ['bed_0',['bed',['../db/dda/ub22_8212_doxy_8scad.html#a6ca1c73b60696cb8d23d257deb53d251',1,'ub22.212Doxy.scad']]],
  ['bottomenddiameter_1',['bottomenddiameter',['../db/dda/ub22_8212_doxy_8scad.html#a5871efe18663d5aa0abba841992ed6a8',1,'ub22.212Doxy.scad']]]
];
