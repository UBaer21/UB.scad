var searchData=
[
  ['quad_0',['quad',['../db/dda/ub22_8212_doxy_8scad.html#a476b29572a3fa1f2f32c5b89e424d87a',1,'ub22.212Doxy.scad']]],
  ['quad_1',['Quad',['../db/dda/ub22_8212_doxy_8scad.html#aa38f5a6d5466b5b4bf10a9a63025f3a3',1,'ub22.212Doxy.scad']]]
];
