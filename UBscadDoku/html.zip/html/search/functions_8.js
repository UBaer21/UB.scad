var searchData=
[
  ['if_0',['if',['../db/dda/ub22_8212_doxy_8scad.html#a98bfc2c4b7aa47b74095350baaa94ad0',1,'if(menu) Menu():&#160;ub22.212Doxy.scad'],['../db/dda/ub22_8212_doxy_8scad.html#ac45b36a097775c3b0b898c8043d8ae22',1,'if(show) %color([0.6:&#160;ub22.212Doxy.scad']]],
  ['imprint_1',['Imprint',['../db/dda/ub22_8212_doxy_8scad.html#a346c98ee512f96f0a31da14ece95a9aa',1,'ub22.212Doxy.scad']]],
  ['inch_2',['inch',['../db/dda/ub22_8212_doxy_8scad.html#ae77778a74a65f1948f36035d851573ec',1,'ub22.212Doxy.scad']]],
  ['infotxt_3',['InfoTxt',['../db/dda/ub22_8212_doxy_8scad.html#a39f65f0acf28320eb1fb5d9f5fa097ba',1,'ub22.212Doxy.scad']]],
  ['inkreis_4',['Inkreis',['../db/dda/ub22_8212_doxy_8scad.html#a08846bf671d0f721dac0e3874da5d912',1,'ub22.212Doxy.scad']]],
  ['involute_5',['involute',['../db/dda/ub22_8212_doxy_8scad.html#a6d3ba89d5eccdca64f92429d3614cedf',1,'ub22.212Doxy.scad']]],
  ['involute_6',['Involute',['../db/dda/ub22_8212_doxy_8scad.html#a62c1d16f56649ae9457aa55db7b1ec01',1,'ub22.212Doxy.scad']]],
  ['is_5fparent_7',['is_parent',['../db/dda/ub22_8212_doxy_8scad.html#a73537a536f0f1d0b7e55cad1069eca10',1,'ub22.212Doxy.scad']]],
  ['isosphere_8',['Isosphere',['../db/dda/ub22_8212_doxy_8scad.html#a5dec847f55663c94ef4486cb1d51a7db',1,'ub22.212Doxy.scad']]]
];
