var searchData=
[
  ['name_0',['name',['../db/dda/ub22_8212_doxy_8scad.html#ab74e6bf80237ddc4109968cedc58c151',1,'ub22.212Doxy.scad']]],
  ['needs2d_1',['needs2D',['../db/dda/ub22_8212_doxy_8scad.html#a399b48652a15c1524d8bde0160f5b2ea',1,'ub22.212Doxy.scad']]],
  ['nozarea_2',['nozArea',['../db/dda/ub22_8212_doxy_8scad.html#a9c04bdfb9c76cd61e7305a8e0298f96c',1,'ub22.212Doxy.scad']]],
  ['nozzle_3',['nozzle',['../db/dda/ub22_8212_doxy_8scad.html#ad6d8226aee2fe24f56500b44c93eaf43',1,'ub22.212Doxy.scad']]]
];
