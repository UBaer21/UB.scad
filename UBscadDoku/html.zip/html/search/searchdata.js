var indexSectionsWithContent =
{
  0: "$abcdefghiklmnopqrstuvwxyz",
  1: "u",
  2: "abcdefghiklmnopqrstuvwz",
  3: "$abcdefghilmnprstuvxyz",
  4: "fghmopu"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Variables",
  4: "Pages"
};

