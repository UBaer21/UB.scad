var searchData=
[
  ['kassette_0',['Kassette',['../db/dda/ub22_8212_doxy_8scad.html#a22ceb4084dbea5fb68387a783cc5e60a',1,'ub22.212Doxy.scad']]],
  ['kathete_1',['Kathete',['../db/dda/ub22_8212_doxy_8scad.html#aa1a240bb7d0a83757fd4caeddcc173dc',1,'ub22.212Doxy.scad']]],
  ['kbs_2',['KBS',['../db/dda/ub22_8212_doxy_8scad.html#a89dd71f5e3126dd4d339554e9435fc47',1,'ub22.212Doxy.scad']]],
  ['kegelmantel_3',['Kegelmantel',['../db/dda/ub22_8212_doxy_8scad.html#a11449dde2a419ff80c13ba2b241b6e99',1,'ub22.212Doxy.scad']]],
  ['kextrude_4',['Kextrude',['../db/dda/ub22_8212_doxy_8scad.html#a62531368bc8473c888c817cffb4ba872',1,'ub22.212Doxy.scad']]],
  ['klammer_5',['Klammer',['../db/dda/ub22_8212_doxy_8scad.html#a5cefe93de6d969a58184c41c29109c2f',1,'ub22.212Doxy.scad']]],
  ['klon_6',['Klon',['../db/dda/ub22_8212_doxy_8scad.html#ad6c970a6b6187920440ff59da1e122fa',1,'ub22.212Doxy.scad']]],
  ['knochen_7',['Knochen',['../db/dda/ub22_8212_doxy_8scad.html#a176e0f5ccda7e06b9f2f42eae67426e8',1,'ub22.212Doxy.scad']]],
  ['knurl_8',['Knurl',['../db/dda/ub22_8212_doxy_8scad.html#a41b5cd05142a662d916e01e303a981f0',1,'ub22.212Doxy.scad']]],
  ['kontaktwinkel_9',['Kontaktwinkel',['../db/dda/ub22_8212_doxy_8scad.html#a7d96ceecadfb330109c97246db4946f1',1,'ub22.212Doxy.scad']]],
  ['kreis_10',['Kreis',['../db/dda/ub22_8212_doxy_8scad.html#ab82c0cbae956878e8020bb4c23da994e',1,'Kreis(r=10, rand=+5, grad=360, grad2, fn=fn, center=true, sek=true, r2=0, rand2, rcenter=0, rot=0, t=[0, 0]):&#160;ub22.212Doxy.scad'],['../db/dda/ub22_8212_doxy_8scad.html#aea4a234136bd1436509fef1250a801d0',1,'Kreis(r=10, rand=0, grad=360, grad2, fn=fn, center=true, sek=false, r2=0, rand2, rcenter=0, rot=0, t=[0, 0], name, help, d, b, fs):&#160;ub22.212Doxy.scad']]],
  ['kreis_11',['kreis',['../db/dda/ub22_8212_doxy_8scad.html#a7515e0d07a61961f110ea8339777b9cc',1,'ub22.212Doxy.scad']]],
  ['kreisbogen_12',['kreisbogen',['../db/dda/ub22_8212_doxy_8scad.html#a82e38da76ee8f0a4e45b1f368e388192',1,'ub22.212Doxy.scad']]],
  ['kreissek_13',['kreisSek',['../db/dda/ub22_8212_doxy_8scad.html#aee27c05ecfd7bd6a963d46c55b30bf25',1,'ub22.212Doxy.scad']]],
  ['kreisxy_14',['KreisXY',['../db/dda/ub22_8212_doxy_8scad.html#aaf104759e325ac6d395e0f99dae3bade',1,'ub22.212Doxy.scad']]],
  ['kreisxy_15',['kreisXY',['../db/dda/ub22_8212_doxy_8scad.html#a4ba5b2d05b87c262cef4b319a99d4eac',1,'ub22.212Doxy.scad']]],
  ['kugelmantel_16',['Kugelmantel',['../db/dda/ub22_8212_doxy_8scad.html#aa0f9aa1cf34af7fa458fb2d99920b04f',1,'ub22.212Doxy.scad']]]
];
