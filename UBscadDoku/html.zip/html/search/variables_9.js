var searchData=
[
  ['inch_0',['inch',['../db/dda/ub22_8212_doxy_8scad.html#a4a1b6f739987dac675305fd49164ac79',1,'ub22.212Doxy.scad']]],
  ['info_1',['info',['../db/dda/ub22_8212_doxy_8scad.html#a7b16a542aaeea764362f9dc2249ae63c',1,'ub22.212Doxy.scad']]]
];
