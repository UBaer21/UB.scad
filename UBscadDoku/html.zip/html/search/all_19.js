var searchData=
[
  ['z_0',['z',['../db/dda/ub22_8212_doxy_8scad.html#a25ed1bcb423b0b7200f485fc5ff71c8e',1,'ub22.212Doxy.scad']]],
  ['zigzag_1',['ZigZag',['../db/dda/ub22_8212_doxy_8scad.html#a00c2da8015a02dbc1fa7a351825249ff',1,'ZigZag(e=5, x=50, y=5, mod=2, delta=+0, base=2, shift=0):&#160;ub22.212Doxy.scad'],['../db/dda/ub22_8212_doxy_8scad.html#a23dfff5f89607d7952896bf7dbe0938c',1,'ZigZag(e=5, es=0, x=50, y=7, mod=2, delta=+0, base=2, shift=0, center=true, name, help):&#160;ub22.212Doxy.scad']]],
  ['zigzag_2',['zigZag',['../db/dda/ub22_8212_doxy_8scad.html#a21c87105d10c3f3f7ad63d30342a67b3',1,'ub22.212Doxy.scad']]],
  ['zylinder_3',['Zylinder',['../db/dda/ub22_8212_doxy_8scad.html#a7daa92be4b7f3ff70aef1ecdbc6c4869',1,'ub22.212Doxy.scad']]]
];
