var searchData=
[
  ['x_0',['x',['../db/dda/ub22_8212_doxy_8scad.html#a9336ebf25087d91c818ee6e9ec29f8c1',1,'ub22.212Doxy.scad']]]
];
