var searchData=
[
  ['y_0',['y',['../db/dda/ub22_8212_doxy_8scad.html#a2fb1c5cf58867b5bbc9a1b145a86f3a0',1,'ub22.212Doxy.scad']]]
];
