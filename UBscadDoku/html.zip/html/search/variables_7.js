var searchData=
[
  ['gcode_0',['gcode',['../db/dda/ub22_8212_doxy_8scad.html#af5b836431a8167bf05c7d5fe516dfd99',1,'ub22.212Doxy.scad']]],
  ['gw_1',['gw',['../db/dda/ub22_8212_doxy_8scad.html#ad246df533d134a22e95b1206e5de6b7a',1,'ub22.212Doxy.scad']]]
];
