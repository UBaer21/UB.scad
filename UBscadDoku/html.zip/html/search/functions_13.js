var searchData=
[
  ['umkreis_0',['Umkreis',['../db/dda/ub22_8212_doxy_8scad.html#a88e2c549fb3ec534fc7d018d02994de5',1,'ub22.212Doxy.scad']]]
];
